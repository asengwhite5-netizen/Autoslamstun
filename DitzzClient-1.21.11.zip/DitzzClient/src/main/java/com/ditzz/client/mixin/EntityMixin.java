package com.ditzz.client.mixin;

import com.ditzz.client.DitzzClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {

    // AntiInvis: pemain invisible tetap kelihatan (client side)
    @Inject(method = "isInvisible", at = @At("HEAD"), cancellable = true)
    private void ditzz$antiInvis(CallbackInfoReturnable<Boolean> cir) {
        if (DitzzClient.antiInvis && (Object) this instanceof AbstractClientPlayerEntity) {
            cir.setReturnValue(false);
        }
    }

    // Hitbox: perbesar area target crosshair untuk pemain lain
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true)
    private void ditzz$hitbox(CallbackInfoReturnable<Float> cir) {
        Object self = this;
        if (DitzzClient.hitbox && self instanceof AbstractClientPlayerEntity
                && self != MinecraftClient.getInstance().player) {
            cir.setReturnValue(cir.getReturnValue() + DitzzClient.hitboxExpand);
        }
    }
}
