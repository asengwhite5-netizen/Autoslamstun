package com.ditzz.client.gui;

import com.ditzz.client.DitzzClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class DitzzScreen extends Screen {
    private static final int PW = 220, PH = 190;

    public DitzzScreen() {
        super(Text.literal(DitzzClient.NAME));
    }

    private int px() { return (this.width - PW) / 2; }
    private int py() { return (this.height - PH) / 2; }

    @Override
    protected void init() {
        int x = px() + 20;
        int y = py() + 34;
        int w = PW - 40;

        toggle(x, y,       w, "SlamStun (manual click)", () -> DitzzClient.slamStun,   v -> DitzzClient.slamStun = v);
        toggle(x, y + 26,  w, "AntiInvis",               () -> DitzzClient.antiInvis,  v -> DitzzClient.antiInvis = v);
        toggle(x, y + 52,  w, "Hitbox",                  () -> DitzzClient.hitbox,     v -> DitzzClient.hitbox = v);
        toggle(x, y + 78,  w, "Brightness",              () -> DitzzClient.brightness, v -> DitzzClient.brightness = v);

        this.addDrawableChild(new HitboxSlider(x, y + 108, w, 20));

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> this.close())
                .dimensions(x, y + 134, w, 20).build());
    }

    private void toggle(int x, int y, int w, String name, BooleanSupplier get, Consumer<Boolean> set) {
        ButtonWidget[] ref = new ButtonWidget[1];
        ref[0] = ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(x, y, w, 20).build();
        this.addDrawableChild(ref[0]);
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "§aON" : "§cOFF"));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.renderBackground(ctx, mouseX, mouseY, delta);
        int x = px(), y = py();
        ctx.fill(x - 1, y - 1, x + PW + 1, y + PH + 1, 0xFF00C8FF); // border
        ctx.fill(x, y, x + PW, y + PH, 0xE0101018);                 // panel
        ctx.fill(x, y, x + PW, y + 24, 0xFF1A1A2E);                 // header
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        String title = "§b§l" + DitzzClient.NAME;
        int tw = this.textRenderer.getWidth(title);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal(title), px() + (PW - tw) / 2, py() + 8, 0xFFFFFFFF);
        ctx.drawTextWithShadow(this.textRenderer, Text.literal("RShift = menu | J K L M = toggle"),
                px() + 20, py() + PH - 14, 0xFF888899);
    }

    @Override
    public boolean shouldPause() { return false; }

    private static class HitboxSlider extends SliderWidget {
        HitboxSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), DitzzClient.hitboxExpand); // 0.0 - 1.0 blok
            updateMessage();
        }
        @Override
        protected void updateMessage() {
            this.setMessage(Text.literal(String.format("Hitbox Size: +%.2f", (float) this.value)));
        }
        @Override
        protected void applyValue() {
            DitzzClient.hitboxExpand = (float) this.value;
        }
    }
}
